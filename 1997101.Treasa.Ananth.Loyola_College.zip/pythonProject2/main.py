# This is a sample Python script.

import csv

find_words = open("find_words.txt", "r")
essay = open("t8.shakespeare.txt", "r")

fields = []
rows = []

#Find the words
find_words_values = find_words.read().split()


#french dict
with open("french_dictionary.csv", 'r') as french_dict:
    csvreader = csv.reader(french_dict)
    for row in csvreader:
        rows.append(row)
#end of french dict

#Essay
essay_values = essay.read()

result = ""

for times, values in enumerate(find_words_values):
    if rows[times][0] == find_words_values[times]:
        result = essay_values.replace(find_words_values[times], rows[times][1])
        essay_values = result
    else:
        print("false")


#create a new file
translate = open("t8.shakespeare.translated.txt", "w")
translate.write(essay_values)
translate.close()

print(result);